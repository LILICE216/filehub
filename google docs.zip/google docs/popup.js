﻿// import { GoogleGenerativeAI } from "./genai.js";
// const API_KEY = "AIzaSyBml9UEzPtxJggDdnyqvWA2vZuV3Owq7d0";
// const genAI = new GoogleGenerativeAI(API_KEY);

// async function sendRequestWithDelay(userPrompt, questionIndex, attempt = 1) {
//     let success = false;

//     while (!success) {
//         try {
//             const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
//             const result = await model.generateContent(`${userPrompt} without explanation just correct answer`);
//             const response = await result.response;
//             const text = await response.text(); // Получаем правильный ответ

//             // Вставляем правильный ответ на активную вкладку
//             chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//                 const tab = tabs[0];
//                 if (tab) {
//                     chrome.scripting.executeScript({
//                         target: { tabId: tab.id },
//                         func: insertCorrectAnswer,
//                         args: [text.trim(), questionIndex] // Передаем правильный ответ и индекс вопроса
//                     });
//                 }
//             });

//             success = true; // Устанавливаем флаг успеха после успешного выполнения
//         } catch (error) {

//             // Если ошибка 429 (слишком много запросов), ждем 5 секунд и повторяем
//             if (error.response && error.response.status === 429) {
//                 await new Promise(resolve => setTimeout(resolve, 5000)); // Задержка перед повтором
//             } else {
//                 // Если ошибка другая, можно повторить попытку не более 3 раз
//                 if (attempt < 3) {
//                     await new Promise(resolve => setTimeout(resolve, 5000)); // Задержка перед повтором
//                     attempt++;
//                 } else {
//                     success = true; // Прерываем цикл после 3 попыток
//                 }
//             }
//         }
//     }
// }

// const clickBtn = document.getElementById("clickButton");
// clickBtn.addEventListener("click", () => {
//     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//         const tab = tabs[0];
//         if (tab) {
//             execScript(tab);
//         } else {
//             alert("There are no active tabs");
//         }
//     });
// });

// function execScript(tab) {
//     chrome.scripting.executeScript(
//         {
//             target: { tabId: tab.id },
//             func: findQuestionsAndAnswers
//         },
//         onResult
//     );
// }

// function findQuestionsAndAnswers() {
//     const questions = document.querySelectorAll(".test-question:not(.resolved)");
//     const results = Array.from(questions).map((question) => {
//         const questionText = question.textContent.trim();
//         const answers = Array.from(
//             question.closest(".test-table").querySelectorAll(".test-answers > li > label")
//         ).map(label => {
//             const text = label.textContent.trim();
//             return text;
//         });
//         return {
//             question: questionText,
//             answers: answers
//         };
//     });

//     return results;
// }

// function onResult(frames) {
//     if (!frames || frames.length === 0 || !frames[0].result) {
//         const errorDiv = document.createElement("div");
//         errorDiv.textContent = "No questions or answers found with the given structure.";
//         errorDiv.style.color = "red";
//         document.body.appendChild(errorDiv);
//         return;
//     }

//     const results = frames[0].result;

//     // Отправляем запросы для каждого вопроса, передавая индекс
//     results.forEach((result, index) => {
//         const userPrompt = `Question: ${result.question}\nAnswers: ${result.answers.join(", ")}`;
//         sendRequestWithDelay(userPrompt, index); // Передаем индекс вопроса
//     });
// }

// function insertCorrectAnswer(correctAnswerText, questionIndex) {
//     // Извлекаем первую букву правильного ответа (например, из "a rises" получаем "a")
//     const match = correctAnswerText.match(/^(\w)/); // Находим первую букву в строке
//     const correctAnswer = match ? match[1].trim() : ''; // Извлекаем первую букву
//     // Найдем все вопросы на странице
//     const questionElements = document.querySelectorAll(".test-question");

//     // Найдем нужный вопрос по индексу
//     const questionElement = questionElements[questionIndex];

//     if (questionElement) {
//         // Находим все варианты ответов для текущего вопроса
//         const answerElements = questionElement.closest(".test-table").querySelectorAll(".test-answers > li > label");

//         // Проходим по каждому варианту ответа и проверяем на совпадение с правильным ответом
//         answerElements.forEach((answerElement) => {
//             const answerText = answerElement.textContent.trim();

//             // Проверяем, совпадает ли первая буква ответа с правильной буквой
//             if (answerText.startsWith(correctAnswer)) {
//                 answerElement.onmouseenter = () => {
//                     answerElement.style.color = 'green';
//                     answerElement.style.cursor = 'pointer';
//                 };

//                 // Убираем эффект при уходе курсора
//                 answerElement.onmouseleave = () => {
//                     answerElement.style.color = 'black';
//                     answerElement.style.cursor = 'default';
//                 };
//             }
//         });
//     }
// }


// -------------------------------------------------------------------------------------------

// import { GoogleGenerativeAI } from "./genai.js";
// const API_KEY = "AIzaSyBml9UEzPtxJggDdnyqvWA2vZuV3Owq7d0";
// const genAI = new GoogleGenerativeAI(API_KEY);

// async function sendRequestWithDelay(userPrompt, questionIndex, attempt = 1) {
//     let success = false;

//     while (!success) {
//         try {
//             const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
//             const result = await model.generateContent(`${userPrompt} without explanation just correct answer`);
//             const response = await result.response;
//             const text = await response.text(); // Получаем правильный ответ

//             // Вставляем правильный ответ на активную вкладку
//             chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//                 const tab = tabs[0];
//                 if (tab) {
//                     chrome.scripting.executeScript({
//                         target: { tabId: tab.id },
//                         func: insertCorrectAnswer,
//                         args: [text.trim(), questionIndex] // Передаем правильный ответ и индекс вопроса
//                     });
//                 }
//             });

//             success = true; // Устанавливаем флаг успеха после успешного выполнения
//         } catch (error) {

//             // Если ошибка 429 (слишком много запросов), ждем 5 секунд и повторяем
//             if (error.response && error.response.status === 429) {
//                 await new Promise(resolve => setTimeout(resolve, 5000)); // Задержка перед повтором
//             } else {
//                 // Если ошибка другая, можно повторить попытку не более 3 раз
//                 if (attempt < 3) {
//                     await new Promise(resolve => setTimeout(resolve, 5000)); // Задержка перед повтором
//                     attempt++;
//                 } else {
//                     success = true; // Прерываем цикл после 3 попыток
//                 }
//             }
//         }
//     }
// }

// const clickBtn = document.getElementById("clickButton");
// clickBtn.addEventListener("click", () => {
//     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//         const tab = tabs[0];
//         if (tab) {
//             execScript(tab);
//         } else {
//             alert("There are no active tabs");
//         }
//     });
// });

// function execScript(tab) {
//     chrome.scripting.executeScript(
//         {
//             target: { tabId: tab.id },
//             func: findQuestionsAndAnswers
//         },
//         onResult
//     );
// }

// function findQuestionsAndAnswers() {
//     const questions = document.querySelectorAll(".test-question:not(.resolved)");
//     const results = Array.from(questions).map((question) => {
//         const questionText = question.textContent.trim();
//         const answers = Array.from(
//             question.closest(".test-table").querySelectorAll(".test-answers > li > label")
//         ).map(label => {
//             const text = label.textContent.trim();
//             return text;
//         });
//         return {
//             question: questionText,
//             answers: answers
//         };
//     });

//     return results;
// }

// function onResult(frames) {
//     if (!frames || frames.length === 0 || !frames[0].result) {
//         const errorDiv = document.createElement("div");
//         errorDiv.textContent = "No questions or answers found with the given structure.";
//         errorDiv.style.color = "red";
//         document.body.appendChild(errorDiv);
//         return;
//     }

//     const results = frames[0].result;

//     // Отправляем запросы для каждого вопроса, передавая индекс
//     results.forEach((result, index) => {
//         const userPrompt = `Question: ${result.question}\nAnswers: ${result.answers.join(", ")}`;
//         sendRequestWithDelay(userPrompt, index); // Передаем индекс вопроса
//     });
// }

// function insertCorrectAnswer(correctAnswerText, questionIndex) {
//     // Извлекаем первую букву правильного ответа (например, из "a rises" получаем "a")
//     const match = correctAnswerText.match(/^(\w)/); // Находим первую букву в строке
//     const correctAnswer = match ? match[1].trim() : ''; // Извлекаем первую букву
//     // Найдем все вопросы на странице
//     const questionElements = document.querySelectorAll(".test-question");

//     // Найдем нужный вопрос по индексу
//     const questionElement = questionElements[questionIndex];

//     if (questionElement) {
//         // Находим все варианты ответов для текущего вопроса
//         const answerElements = questionElement.closest(".test-table").querySelectorAll(".test-answers > li > label");

//         // Проходим по каждому варианту ответа и проверяем на совпадение с правильным ответом
//         answerElements.forEach((answerElement) => {
//             const answerText = answerElement.textContent.trim();

//             // Проверяем, совпадает ли первая буква ответа с правильной буквой
//             if (answerText.startsWith(correctAnswer)) {
//                 // Применяем стиль зеленого цвета к правильному ответу
//                 answerElement.style.color = 'green';
//                 answerElement.style.fontWeight = 'bold'; // Дополнительно можно выделить правильный ответ жирным
//             }
//         });
//     }
// }

// -------------------------------------------------------------------------------------------

import { GoogleGenerativeAI } from "./genai.js";
const API_KEY = "AIzaSyBml9UEzPtxJggDdnyqvWA2vZuV3Owq7d0";
const genAI = new GoogleGenerativeAI(API_KEY);

async function sendRequestWithDelay(userPrompt) {
    let success = false;

    while (!success) {
        try {
            const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
            const result = await model.generateContent(`${userPrompt} without explanation just correct answer`);
            const response = await result.response;
            const text = await response.text(); // Получаем правильный ответ

            // Выводим все ответы в body расширения
            appendAnswersToBody(text);

            success = true; // Устанавливаем флаг успеха после успешного выполнения
        } catch (error) {

            // Если ошибка 429 (слишком много запросов), ждем 5 секунд и повторяем
            if (error.response && error.response.status === 429) {
                await new Promise(resolve => setTimeout(resolve, 5000)); // Задержка перед повтором
            } else {
                // Если ошибка другая, пытаемся повторить запрос через 5 секунд
                await new Promise(resolve => setTimeout(resolve, 5000)); // Задержка перед повтором
            }
        }
    }
}

const clickBtn = document.getElementById("clickButton");
clickBtn.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        if (tab) {
            execScript(tab);
        } else {
            alert("There are no active tabs");
        }
    });
});

function execScript(tab) {
    chrome.scripting.executeScript(
        {
            target: { tabId: tab.id },
            func: findQuestionsAndAnswers
        },
        onResult
    );
}

function findQuestionsAndAnswers() {
    const questions = document.querySelectorAll(".test-question:not(.resolved)");
    const results = Array.from(questions).map((question) => {
        const questionText = question.textContent.trim();
        const answers = Array.from(
            question.closest(".test-table").querySelectorAll(".test-answers > li > label")
        ).map(label => {
            const text = label.textContent.trim();
            return text;
        });
        return {
            question: questionText,
            answers: answers
        };
    });

    return results;
}

function onResult(frames) {
    if (!frames || frames.length === 0 || !frames[0].result) {
        const errorDiv = document.createElement("div");
        errorDiv.textContent = "No questions or answers found with the given structure.";
        errorDiv.style.color = "red";
        document.body.appendChild(errorDiv);
        return;
    }

    const results = frames[0].result;

    // Формируем запрос с данными всех вопросов и вариантов
    const userPrompt = results.map(result =>
        `Question: ${result.question}\nAnswers: ${result.answers.join(", ")}`
    ).join("\n\n");

    // Отправляем один запрос на сервер
    sendRequestWithDelay(userPrompt);
}

function appendAnswersToBody(answerText) {
    alert('Готово!');
    // Создаем элемент <div>, в который будем вставлять ответы
    const answersContainer = document.createElement("div");
    answersContainer.style.padding = "10px";
    answersContainer.style.backgroundColor = "#f4f4f4";
    answersContainer.style.borderRadius = "8px";
    answersContainer.style.marginTop = "20px";

    const answerTitle = document.createElement("h3");
    answerTitle.textContent = "Correct Answers:";
    answersContainer.appendChild(answerTitle);

    const answerList = document.createElement("ul");

    // Разделяем ответ на строки и добавляем их в список
    const answers = answerText.split("\n").filter(line => line.trim().length > 0);
    answers.forEach(answer => {
        const listItem = document.createElement("li");
        listItem.textContent = answer.trim();
        answerList.appendChild(listItem);
    });

    answersContainer.appendChild(answerList);

    // Добавляем контейнер с ответами в body расширения
    document.body.appendChild(answersContainer);
}
