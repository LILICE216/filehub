Object.defineProperty(document, "hidden", {
    get: () => false
  });
  
  Object.defineProperty(document, "visibilityState", {
    get: () => "visible"
  });
  
  window.addEventListener("visibilitychange", (event) => {
    event.stopImmediatePropagation();
  }, true);
  