chrome.scripting.registerContentScripts([
    {
      id: "override_visibility",
      matches: ["<all_urls>"],
      js: ["content.js"],
      runAt: "document_start"
    }
  ]);
  